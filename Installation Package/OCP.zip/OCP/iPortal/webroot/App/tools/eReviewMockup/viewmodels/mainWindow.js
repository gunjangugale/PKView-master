﻿define(function (require)
{
    // This is the mainWindow viewmodel prototype
    var mainWindow = function ()
    {
        var self = this;
    };

    mainWindow.prototype.attached = function ()
    {
    };

    return mainWindow;
});